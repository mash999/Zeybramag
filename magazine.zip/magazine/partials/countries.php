<optgroup label="Africa">
      <option value="dz" data-country="Algeria">Algeria</option>
      <option value="ao" data-country="Angola">Angola</option>
      <option value="bj" data-country="Benin">Benin</option>
      <option value="bw" data-country="Botswana">Botswana</option>
      <option value="bf" data-country="Burkina Faso">Burkina Faso</option>
      <option value="bi" data-country="Burundi">Burundi</option>
      <option value="cm" data-country="Cameroon">Cameroon</option>
      <option value="cv" data-country="Cape Verde">Cape Verde</option>
      <option value="cf" data-country="Central African Republic">Central African Republic</option>
      <option value="td" data-country="Chad">Chad</option>
      <option value="km" data-country="Comoros">Comoros</option>
      <option value="cg" data-country="Congo">Congo</option>
      <option value="ci" data-country="Cote d'Ivoire">Cote d'Ivoire</option>
      <option value="dj" data-country="Djibouti">Djibouti</option>
      <option value="eg" data-country="Egypt">Egypt</option>
      <option value="gq" data-country="Equatorial Guinea">Equatorial Guinea</option>
      <option value="er" data-country="Eritrea">Eritrea</option>
      <option value="et" data-country="Ethiopia">Ethiopia</option>
      <option value="ga" data-country="Gabon">Gabon</option>
      <option value="gm" data-country="Gambia">Gambia</option>
      <option value="gh" data-country="Ghana">Ghana</option>
      <option value="gn" data-country="Guinea">Guinea</option>
      <option value="gw" data-country="Guinea-Bissau">Guinea-Bissau</option>
      <option value="ke" data-country="Kenya">Kenya</option>
      <option value="ls" data-country="Lesotho">Lesotho</option>
      <option value="lr" data-country="Liberia">Liberia</option>
      <option value="ly" data-country="Libya">Libya</option>
      <option value="mg" data-country="Madagascar">Madagascar</option>
      <option value="mw" data-country="Malawi">Malawi</option>
      <option value="ml" data-country="Mali">Mali</option>
      <option value="mr" data-country="Mauritania">Mauritania</option>
      <option value="mu" data-country="Mauritius">Mauritius</option>
      <option value="yt" data-country="Mayotte">Mayotte</option>
      <option value="ma" data-country="Morocco">Morocco</option>
      <option value="mz" data-country="Mozambique">Mozambique</option>
      <option value="na" data-country="Namibia">Namibia</option>
      <option value="ne" data-country="Niger">Niger</option>
      <option value="ng" data-country="Nigeria">Nigeria</option>
      <option value="re" data-country="Reunion">Reunion</option>
      <option value="rw" data-country="Rwanda">Rwanda</option>
      <option value="sh" data-country="Saint Helena">Saint Helena</option>
      <option value="st" data-country="Sao Tome">Sao Tome</option>
      <option value="sn" data-country="Senegal">Senegal</option>
      <option value="sc" data-country="Seychelles">Seychelles</option>
      <option value="sl" data-country="Sierra Leone">Sierra Leone</option>
      <option value="so" data-country="Somalia">Somalia</option>
      <option value="za" data-country="South Africa">South Africa</option>
      <option value="sd" data-country="Sudan">Sudan</option>
      <option value="sz" data-country="Swaziland">Swaziland</option>
      <option value="tz" data-country="Tanzania">Tanzania</option>
      <option value="tg" data-country="Togo">Togo</option>
      <option value="tn" data-country="Tunisia">Tunisia</option>
      <option value="ug" data-country="Uganda">Uganda</option>
      <option value="eh" data-country="Western Sahara">Western Sahara</option>
      <option value="zm" data-country="Zambia">Zambia</option>
      <option value="zw" data-country="Zimbabwe">Zimbabwe</option>
</optgroup>



<optgroup label="America">
      <option value="ai" data-country="Anguilla">Anguilla</option>
      <option value="ag" data-country="Antigua and Barbuda">Antigua and Barbuda</option>
      <option value="ar" data-country="Argentina">Argentina</option>
      <option value="aw" data-country="Aruba">Aruba</option>
      <option value="bs" data-country="Bahamas">Bahamas</option>
      <option value="bb" data-country="Barbados">Barbados</option>
      <option value="bz" data-country="Belize">Belize</option>
      <option value="bm" data-country="Bermuda">Bermuda</option>
      <option value="bo" data-country="Bolivia">Bolivia</option>
      <option value="br" data-country="Brazil">Brazil</option>
      <option value="ca" data-country="Canada">Canada</option>
      <option value="ky" data-country="Cayman Islands">Cayman Islands</option>
      <option value="cl" data-country="Chile">Chile</option>
      <option value="co" data-country="Colombia">Colombia</option>
      <option value="cr" data-country="Costa Rica">Costa Rica</option>
      <option value="cu" data-country="Cuba">Cuba</option>
      <option value="dm" data-country="Dominica">Dominica</option>
      <option value="do" data-country="Dominican Republic">Dominican Republic</option>
      <option value="ec" data-country="Ecuador">Ecuador</option>
      <option value="sv" data-country="El Salvador">El Salvador</option>
      <option value="fk" data-country="Falkland Islands">Falkland Islands</option>
      <option value="gf" data-country="French Guiana">French Guiana</option>
      <option value="gl" data-country="Greenland">Greenland</option>
      <option value="gd" data-country="Grenada">Grenada</option>
      <option value="gp" data-country="Guadeloupe">Guadeloupe</option>
      <option value="gt" data-country="Guatemala">Guatemala</option>
      <option value="gy" data-country="Guyana">Guyana</option>
      <option value="ht" data-country="Haiti">Haiti</option>
      <option value="hn" data-country="Honduras">Honduras</option>
      <option value="jm" data-country="Jamaica">Jamaica</option>
      <option value="mq" data-country="Martinique">Martinique</option>
      <option value="mx" data-country="Mexico">Mexico</option>
      <option value="ms" data-country="Montserrat">Montserrat</option>
      <option value="an" data-country="Netherlands Antilles">Netherlands Antilles</option>
      <option value="ni" data-country="Nicaragua">Nicaragua</option>
      <option value="pa" data-country="Panama">Panama</option>
      <option value="py" data-country="Paraguay">Paraguay</option>
      <option value="pe" data-country="Peru">Peru</option>
      <option value="pr" data-country="Puerto Rico">Puerto Rico</option>
      <option value="bl" data-country="Saint Barthelemy">Saint Barthelemy</option>
      <option value="kn" data-country="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
      <option value="lc" data-country="Saint Lucia">Saint Lucia</option>
      <option value="mf" data-country="Saint Martin">Saint Martin</option>
      <option value="pm" data-country="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
      <option value="vc" data-country="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
      <option value="sr" data-country="Suriname">Suriname</option>
      <option value="tt" data-country="Trinidad and Tobago">Trinidad and Tobago</option>
      <option value="tc" data-country="Turks and Caicos Islands">Turks and Caicos Islands</option>
      <option value="us" data-country="United States">United States</option>
      <option value="uy" data-country="Uruguay">Uruguay</option>
      <option value="ve" data-country="Venezuelaf">Venezuelaf</option>
      <option value="vg" data-country="Virgin Islands, British">Virgin Islands, British</option>
      <option value="vi" data-country="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
</optgroup>




<optgroup label="Asia">
      <option value="af" data-country="Afghanistan">Afghanistan</option>
      <option value="am" data-country="Armenia">Armenia</option>
      <option value="az" data-country="Azerbaijan">Azerbaijan</option>
      <option value="bh" data-country="Bahrain">Bahrain</option>
      <option value="bd" data-country="Bangladesh">Bangladesh</option>
      <option value="bt" data-country="Bhutan">Bhutan</option>
      <option value="bn" data-country="Brunei Darussalam">Brunei Darussalam</option>
      <option value="kh" data-country="Cambodia">Cambodia</option>
      <option value="cn" data-country="China">China</option>
      <option value="cy" data-country="Cyprus">Cyprus</option>
      <option value="ge" data-country="Georgia">Georgia</option>
      <option value="hk" data-country="Hong Kong">Hong Kong</option>
      <option value="in" data-country="India">India</option>
      <option value="id" data-country="Indonesia">Indonesia</option>
      <option value="ir" data-country="Iran">Iran</option>
      <option value="iq" data-country="Iraq">Iraq</option>
      <option value="il" data-country="Israel">Israel</option>
      <option value="jp" data-country="Japan">Japan</option>
      <option value="jo" data-country="Jordan">Jordan</option>
      <option value="kz" data-country="Kazakhstan">Kazakhstan</option>
      <option value="kp" data-country="Korea">Korea</option>
      <option value="kr" data-country="Korea">Korea</option>
      <option value="kw" data-country="Kuwait">Kuwait</option>
      <option value="kg" data-country="Kyrgyzstan">Kyrgyzstan</option>
      <option value="la" data-country="Lao">Lao</option>
      <option value="lb" data-country="Lebanon">Lebanon</option>
      <option value="mo" data-country="Macao">Macao</option>
      <option value="my" data-country="Malaysia">Malaysia</option>
      <option value="mv" data-country="Maldives">Maldives</option>
      <option value="mn" data-country="Mongolia">Mongolia</option>
      <option value="mm" data-country="Myanmar">Myanmar</option>
      <option value="np" data-country="Nepal">Nepal</option>
      <option value="om" data-country="Oman">Oman</option>
      <option value="pk" data-country="Pakistan">Pakistan</option>
      <option value="ps" data-country="Palestinian Territo">Palestinian Territo</option>
      <option value="ph" data-country="Philippines">Philippines</option>
      <option value="qa" data-country="Qatar">Qatar</option>
      <option value="sa" data-country="Saudi Arabia">Saudi Arabia</option>
      <option value="sg" data-country="Singapore">Singapore</option>
      <option value="lk" data-country="Sri Lanka">Sri Lanka</option>
      <option value="sy" data-country="Syria">Syria</option>
      <option value="tw" data-country="Taiwan">Taiwan</option>
      <option value="tj" data-country="Tajikistan">Tajikistan</option>
      <option value="th" data-country="Thailand">Thailand</option>
      <option value="tl" data-country="Timor-Leste">Timor-Leste</option>
      <option value="tr" data-country="Turkey">Turkey</option>
      <option value="tm" data-country="Turkmenistan">Turkmenistan</option>
      <option value="ae" data-country="UAE">UAE</option>
      <option value="uz" data-country="Uzbekistan">Uzbekistan</option>
      <option value="vn" data-country="Vietnam">Vietnam</option>
      <option value="ye" data-country="Yemen">Yemen</option>
</optgroup>




<optgroup label="Europe">
      <option value="ax" data-country="Aland Islands">Aland Islands</option>
      <option value="al" data-country="Albania">Albania</option>
      <option value="ad" data-country="Andorra">Andorra</option>
      <option value="at" data-country="Austria">Austria</option>
      <option value="by" data-country="Belarus">Belarus</option>
      <option value="be" data-country="Belgium">Belgium</option>
      <option value="ba" data-country="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
      <option value="bg" data-country="Bulgaria">Bulgaria</option>
      <option value="hr" data-country="Croatia">Croatia</option>
      <option value="cz" data-country="Czech Republic">Czech Republic</option>
      <option value="dk" data-country="Denmark">Denmark</option>
      <option value="ee" data-country="Estonia">Estonia</option>
      <option value="fo" data-country="Faroe Islands">Faroe Islands</option>
      <option value="fi" data-country="Finland">Finland</option>
      <option value="fr" data-country="France">France</option>
      <option value="de" data-country="Germany">Germany</option>
      <option value="gi" data-country="Gibraltar">Gibraltar</option>
      <option value="gr" data-country="Greece">Greece</option>
      <option value="gg" data-country="Guernsey">Guernsey</option>
      <option value="va" data-country="Holy See">Holy See</option>
      <option value="hu" data-country="Hungary">Hungary</option>
      <option value="is" data-country="Iceland">Iceland</option>
      <option value="ie" data-country="Ireland">Ireland</option>
      <option value="it" data-country="Italy">Italy</option>
      <option value="je" data-country="Jersey">Jersey</option>
      <option value="lv" data-country="Latvia">Latvia</option>
      <option value="li" data-country="Liechtenstein">Liechtenstein</option>
      <option value="lt" data-country="Lithuania">Lithuania</option>
      <option value="lu" data-country="Luxembourg">Luxembourg</option>
      <option value="mk" data-country="Macedonia">Macedonia</option>
      <option value="mt" data-country="Malta">Malta</option>
      <option value="md" data-country="Moldova">Moldova</option>
      <option value="mc" data-country="Monaco">Monaco</option>
      <option value="me" data-country="Montenegro">Montenegro</option>
      <option value="nl" data-country="Netherlands">Netherlands</option>
      <option value="no" data-country="Norway">Norway</option>
      <option value="pl" data-country="Poland">Poland</option>
      <option value="pt" data-country="Portugal">Portugal</option>
      <option value="ro" data-country="Romania">Romania</option>
      <option value="ru" data-country="Russian Federation">Russian Federation</option>
      <option value="sm" data-country="San Marino">San Marino</option>
      <option value="rs" data-country="Serbia">Serbia</option>
      <option value="sk" data-country="Slovakia">Slovakia</option>
      <option value="si" data-country="Slovenia">Slovenia</option>
      <option value="es" data-country="Spain">Spain</option>
      <option value="sj" data-country="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
      <option value="se" data-country="Sweden">Sweden</option>
      <option value="ch" data-country="Switzerland">Switzerland</option>
      <option value="ua" data-country="Ukraine">Ukraine</option>
      <option value="gb" data-country="United Kingdom">United Kingdom</option>
</optgroup>




<optgroup label="Australia and Oceania">
      <option value="as" data-country="American Samoa">American Samoa</option>
      <option value="au" data-country="Australia">Australia</option>
      <option value="ck" data-country="Cook Islands">Cook Islands</option>
      <option value="fj" data-country="Fiji">Fiji</option>
      <option value="pf" data-country="French Polynesia">French Polynesia</option>
      <option value="gu" data-country="Guam">Guam</option>
      <option value="ki" data-country="Kiribati">Kiribati</option>
      <option value="mh" data-country="Marshall Islands">Marshall Islands</option>
      <option value="fm" data-country="Micronesia">Micronesia</option>
      <option value="nr" data-country="Nauru">Nauru</option>
      <option value="nc" data-country="New Caledonia">New Caledonia</option>
      <option value="nz" data-country="New Zealand">New Zealand</option>
      <option value="nu" data-country="Niue">Niue</option>
      <option value="nf" data-country="Norfolk Island">Norfolk Island</option>
      <option value="mp" data-country="Northern Mariana Islands">Northern Mariana Islands</option>
      <option value="pw" data-country="Palau">Palau</option>
      <option value="pg" data-country="Papua New Guinea">Papua New Guinea</option>
      <option value="pn" data-country="Pitcairn">Pitcairn</option>
      <option value="ws" data-country="Samoa">Samoa</option>
      <option value="sb" data-country="Solomon Islands">Solomon Islands</option>
      <option value="tk" data-country="Tokelau">Tokelau</option>
      <option value="to" data-country="Tonga">Tonga</option>
      <option value="tv" data-country="Tuvalu">Tuvalu</option>
      <option value="vu" data-country="Vanuatu">Vanuatu</option>
      <option value="wf" data-country="Wallis and Futuna">Wallis and Futuna</option>
</optgroup>




<optgroup label="Other areas">
      <option value="bv" data-country="Bouvet Island">Bouvet Island</option>
      <option value="io" data-country="British Indian Ocean">British Indian Ocean</option>
      <option value="eu" data-country="European Union">European Union</option>
      <option value="tf" data-country="French Southern Territory">French Southern Territory</option>
      <option value="hm" data-country="Heard Island">Heard Island</option>
      <option value="gs" data-country="South Georgia">South Georgia</option>
      <option value="um" data-country="United States Minor">United States Minor</option>
</optgroup>